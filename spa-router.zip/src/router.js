export const ROUTES = {};

export const setRoutes = (routes) => {
  routes.forEach((route) => {
    ROUTES[route.path] = route.component;
  });
};

export const getComponentByRoute = (pathname) => {
  if (Object.keys(ROUTES).includes(pathname)) {
    return ROUTES[pathname];
  }
  const defaultRoute = ROUTES.find((route) => route.path === '*');
  if (defaultRoute) {
    return defaultRoute.component;
  }
  throw new Error('No route found');
};

export const renderComponent = () => {
  const component = getComponentByRoute(window.location.pathname);
  const rootSection = document.getElementById('root');
  rootSection.innerHTML = '';
  rootSection.appendChild(component());
};

export const navigate = (pathname) => {
  window.history.pushState({}, pathname, window.location.origin + pathname);
  renderComponent();
};

export const handlePopState = () => {
  renderComponent();
};
