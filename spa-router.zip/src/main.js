// import { onAuthStateChange } from './lib/fireBase';
import Home from './components/home.js';
import Register from './components/register.js';
import Feed from './components/feed.js';
import NotFound from './components/404.js';

import {
  // navigate,
  setRoutes,
  handlePopState,
  renderComponent,
} from './router.js';

// agregamos el evento popstate para que
// podamos volver atras en el navegador
window.onpopstate = handlePopState;

// Creamos un arreglo de rutas
const routes = [
  {
    path: '/',
    component: Home,
  },
  {
    path: '/register',
    component: Register,
  },
  {
    path: '/feed',
    component: Feed,
  },
  {
    path: '*',
    component: NotFound,
  },
];

// agregamos las rutas al router
setRoutes(routes);

// si no renderizamos el primer componente
// con auhtStateChange
renderComponent();

// si renderizamos el primer componente
// con auhtStateChange
// onAuthStateChange(
//   (user) => new Promise((resolve) => {
//     if (user) {
//       navigate('/feed').then(resolve);
//     } else {
//       navigate('/').then(resolve);
//     }
//   }),
// );
